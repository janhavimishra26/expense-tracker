const express = require ('express');
const app = express();
const port = 5000;
const db = require('./db');

app.get('/', (req,res)=>{
    res.send('Server is running !')
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});


app.get('/api/users',(req,res)=>{
    const sqlQuery = "SELECT * FROM users";

    db.query(sqlQuery, (err,result)=>{
        if(err){
            return res.status(500).json({error:err.message});
        }
        res.json(result);
    });
});

app.post('/add-user',(req,res)=>{
    const userNAME = req.body.name;
    const sqlInsert = "INSERT INTO users (name) VALUES(?)";

    db.query(sqlInsert, [userNAME], (err,result)=>{
        if(err) return res.send(err);
        res.send("User added");
    })
})

app.put('/update-user/:id',(req,res)=>{
    const userID = req.params.id;
    const newName = req.body.name;

    const sqlUpdate = "UPDATE users SET name = ? WHERE id = ?";

    db.query(sqlUpdate, [newName, userID], (err,result)=>{
        if(err) return res.send(err);
        res.send("user updated!");
    });
});

app.delete('/delete-user/:id', (req, res)=>{
    const userID = req.params.id;
    const sqlDelete = "DELETE FROM users WHERE id=?";
    
    db.query(sqlDelete,[userID],(err,result)=>{
        if(err) return res.send(err);
        res.send("deleted!");
    });
});